export default {
    marginBottom: 8,
}