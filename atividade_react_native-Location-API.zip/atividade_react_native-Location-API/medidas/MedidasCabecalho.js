export default{
    CabecalhoWidth: '100%',
    CabecalhoHeight: 95,
    CabecalhoPaddinTop: 40,
    CabecalhoAlignItems: 'center',
    CabecalhoJustifyContent: 'center'
}