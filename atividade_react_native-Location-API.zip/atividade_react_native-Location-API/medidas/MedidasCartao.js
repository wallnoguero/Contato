export default{
    cartaoMargin: 2,
    cartaoPadding: 12
}