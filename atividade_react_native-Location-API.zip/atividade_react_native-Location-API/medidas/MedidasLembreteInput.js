export default{
    LembreteInputWidth: '80%',
    LembreteInputPadding: 2,
    LembreteInputMarginBttm: 2,
    LembreteInputFlexDirectionView: 'row',
    LembreteInputJustifyContentView: 'space-between',
    LembreteInputAlignItemsView: 'center',
    LembreteInputMarginBottomView: 6
}