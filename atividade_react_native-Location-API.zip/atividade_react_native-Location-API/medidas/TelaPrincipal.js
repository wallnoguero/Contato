  
export default{
    TelaPrincipalPadding: 25
}