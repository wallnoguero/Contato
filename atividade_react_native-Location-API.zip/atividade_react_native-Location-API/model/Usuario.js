class Usuario {
    constructor(id, nome, telefone, imagemURI, latitude, longitude){
        this.id = id;
        this.nome = nome;
        this.telefone = telefone;
        this.imagemURI = imagemURI;
        this.latitude = latitude;
        this.longitude = longitude;
    }
}

export default Usuario;